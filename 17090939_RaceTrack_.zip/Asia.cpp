#include "Asia.h"

Asia::Asia():TrackContinent() {
	// TODO - implement Asia::Asia

	cout << "Asian Race Track" << endl;
		setLaps(3);
		setWear(4);

		setSpeed(7);

		setCorners(5);

		setLength(8);


		setFatigue(4);

		setCity("Tokyo");
}
