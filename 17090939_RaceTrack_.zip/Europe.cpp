#include "Europe.h"

Europe::Europe() {
	// TODO - implement Europe::Europe

	cout << "Europe Race Track" << endl;
			setLaps(5);
			setWear(2);

			setSpeed(4);

			setCorners(10);

			setLength(8);


			setFatigue(3);

			setCity("paris");
}
