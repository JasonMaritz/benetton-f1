#include "European.h"

European::European() {
	// TODO - implement European::European


		cout << "European Teams" << endl;
		//setLaps(5);
		//setWear(5);

		//setSpeed(4);

		//setCorners(5);

		//setLength(8);


		//setFatigue(3);

		//setCity("Pretoria");
}
