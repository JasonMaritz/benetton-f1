#ifndef NAMERICA_H
#define NAMERICA_H
#include"TrackContinent.h"
#include<iostream>
#include<string>
using namespace std;

class NAmerica : public TrackContinent {


public:
	NAmerica();
};

#endif
