#include "RaceCategory.h"



RaceCategory::RaceCategory() {
	// TODO - implement RaceCategory::RaceCategory
}
void RaceCategory::add(Track* track){

}
int RaceCategory::trackLaps(){


		 return getLaps();

}
int RaceCategory::trackWear(){

			 return getWear();

}
int RaceCategory::trackSpeed(){

			 return getSpeed();

}
int RaceCategory::trackCorner(){

			 return getCorners();

}
int RaceCategory::trackLength(){

			 return getLength();

 }
int RaceCategory::trackFatigues(){

			 return getFatigue();

}
string RaceCategory::trackCity(){

			 return getCity();

}


