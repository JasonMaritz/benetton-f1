#include "SAmerica.h"

SAmerica::SAmerica():TrackContinent() {
	// TODO - implement SAmerica::SAmerica

	cout << "South america Race Track" << endl;
			setLaps(5);
			setWear(9);

			setSpeed(4);

			setCorners(5);

			setLength(8);


			setFatigue(3);

			setCity("Rio");
}
