There are two options to run our program:

1) if you do not want to install cmake to make a new make file you can just navigate 
to the Benetton_F1 folder and execute the command "./Benetton_F1"

2) if you have cmake you can make a new make file specifically for your system by 
    1) "cmake CMAKELists.txt"
    2) "make"
    3) "./Benetton_F1"