#ifndef LOCATION_H
#define LOCATION_H

#include <string>

using namespace std;

class Location
{
public:
	string name;
	bool european;
};

#endif