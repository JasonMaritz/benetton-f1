#include "PackedItem.h"

PackedItem* PackedItem::clone() {
	return new PackedItem;
}