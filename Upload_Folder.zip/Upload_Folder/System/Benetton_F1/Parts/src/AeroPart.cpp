//
// Created by jason on 2020/11/03.
//

#include "../include/AeroPart.h"

AeroPart::AeroPart() {
    wear = 1;
    powerContribution = 0.5;
    powerDraw = 0.5;
    efficiency = 0.5;
}
