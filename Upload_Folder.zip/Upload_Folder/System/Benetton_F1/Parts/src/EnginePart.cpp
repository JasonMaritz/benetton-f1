//
// Created by jason on 2020/11/03.
//

#include "../include/EnginePart.h"

EnginePart::EnginePart() {
    wear = 1;
    powerContribution = 0.5;
    powerDraw = 0.5;
    efficiency = 0.5;
}
