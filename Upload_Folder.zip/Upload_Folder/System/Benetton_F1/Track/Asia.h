/**
 * Asian Track
 * Description: concrete Decorator that adds responsibilities to the Track( component)
 */
#ifndef ASIA_H
#define ASIA_H
#include"TrackContinent.h"
#include<iostream>
#include<string>
using namespace std;

class Asia : public TrackContinent {


public:
	Asia();
};

#endif
