/**
 * European
 * Description: adds additional responsibilities to the earopean Race Tracks
 */
#ifndef EUROPEAN_H
#define EUROPEAN_H
#include"RaceCategory.h"
#include<iostream>
#include<string>
using namespace std;

class European : public RaceCategory {


public:
	European();
};

#endif
