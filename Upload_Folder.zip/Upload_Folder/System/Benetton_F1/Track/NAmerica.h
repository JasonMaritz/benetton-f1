/**
 * North american Track
 * Description: concrete Decorator that adds responsibilities to the Track( component)
 */
#ifndef NAMERICA_H
#define NAMERICA_H
#include"TrackContinent.h"
#include<iostream>
#include<string>
using namespace std;

class NAmerica : public TrackContinent {


public:
	NAmerica();
};

#endif
