#include "NonEuropean.h"

 /**
  * the .h file of the Non European race Track
  */
NonEuropean::NonEuropean() {
	// TODO - implement NonEuropean::NonEuropean

	cout << "Non European Teams" << endl;
			//setLaps(3);
			//setWear(5);

			//setSpeed(8);

			//setCorners(12);

			//setLength(4);

			//setFatigue(3);

			//setCity("Pretoria");
}
