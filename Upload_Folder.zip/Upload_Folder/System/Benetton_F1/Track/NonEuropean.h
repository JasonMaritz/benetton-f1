/**
 * Non European
 * Description: adds additional responsibilities to the Non European Race Tracks
 */#ifndef NONEUROPEAN_H
#define NONEUROPEAN_H
#include"RaceCategory.h"
#include<iostream>
#include<string>
using namespace std;

class NonEuropean :public RaceCategory {


public:
	NonEuropean();
};

#endif
