/**
 * south afmerican Track
 * Description: concrete Decorator that adds responsibilities to the Track( component)
 */
#ifndef SAMERICA_H
#define SAMERICA_H
#include"TrackContinent.h"
#include<iostream>
#include<string>
using namespace std;

class SAmerica : public TrackContinent {


public:
	SAmerica();
};

#endif
