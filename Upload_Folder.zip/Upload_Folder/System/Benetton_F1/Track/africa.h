/**
 * African Track
 * Description: concrete Decorator that adds responsibilities to the Track( component)
 */

#ifndef AFRICA_H
#define AFRICA_H
#include"TrackContinent.h"
#include<iostream>
#include<string>
using namespace std;


class africa : public TrackContinent {


public:
	africa();

};

#endif
